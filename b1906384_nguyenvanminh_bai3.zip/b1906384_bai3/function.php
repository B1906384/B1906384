<?php
declare(strict_types=0);
function addNumbers(int $a, int $b) {
  return $a + $b;
}
echo addNumbers(5, 10);
// it will return 15
echo addNumbers(5, "10 so");
// neu 1 tham so la chuoi co the se xuat thong bao loi
?>
